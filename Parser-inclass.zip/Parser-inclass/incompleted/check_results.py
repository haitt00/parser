import sys

filename1 = sys.argv[1]
filename2 = sys.argv[2]
# print(filename1)
# print(filename2)
file1 = open(filename1)
content1 = file1.read()

file2 = open(filename2)
content2 = file2.read()

# print(content1)
# print(content2)

# print(len(content1))
# print(len(content2))
count = 0
for x in range(len(content1)):
	if content1[x]!=content2[x]:
		if count<10:
			count+=1
			print(content1[x])
			# print(content2[x])
			# print(x)
print(content1==content2)